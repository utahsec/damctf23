Just fyi - the anticheat key is different on the real server, so if you connect to this server as is the descriptions will be messed up.
